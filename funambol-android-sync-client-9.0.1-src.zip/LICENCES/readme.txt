
Related software rights:

This product includes software developed by the Joda project 
(http://joda-time.sourceforge.net)
