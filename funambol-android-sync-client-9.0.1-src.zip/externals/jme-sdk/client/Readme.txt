Funambol Java Client API

Version: 8.5.0

OVERVIEW
--------
This library is a collection of components aimed at helping the development of
synchronization clients. The build system allows a modular build of the library
so that only needed components can be included in clients.

See the javadoc for more information on the structure of the library.


BUILD
-----
See the how_to_build.txt for all the details.

-----------

Funambol offers commercial support for this software.
See http://www.funambol.com/support.

You can also get support from the open source community.
See http://www.funambol.com/opensource/support.

Copyright (c) 2007 Funambol. All rights reserved. 

