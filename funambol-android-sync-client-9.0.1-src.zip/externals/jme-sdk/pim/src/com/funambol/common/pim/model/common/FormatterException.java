package com.funambol.common.pim.model.common;

public class FormatterException extends Exception {

    public FormatterException() {
        super();
    }

    public FormatterException(String msg) {
        super(msg);
    }
}
